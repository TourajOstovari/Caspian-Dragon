﻿using System.Linq;
using System.Text;

internal class Program
{
    private static void Main()
    {
        string in_x = ""; float q, p, V, w, AlphaV, T, AlphaT; int w2; float SUM_X = 0;
        Console.WriteLine("\nEnter q: (ex: 1.5)\n");
        q = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter p: (ex: 2.6)\n");
        p = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter w: (55.5)\n");
        w = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter V: (1 -- ~)\n");
        V = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha V: (1 -- ~)\n");
        AlphaV = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter T: (1 -- ~)\n");
        T = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha T: (1 -- ~)\n");
        AlphaT = float.Parse(Console.ReadLine());
        w2 = (int)w % 2;

        bool ISFILE = false;
        int[,,] inputs_x = new int[1024, 1024, 1024];
        Console.WriteLine("File or Text as input ??Y/N (Y == FILE || N == TEXT)\n");
        if (Console.ReadKey().ToString().ToLower() == "y")
        {
            Console.WriteLine("\nPlease write File Address here: \n");
            ISFILE = true;
        }
        else
        {
            Console.WriteLine("\nPlease write TEXT here: \n");
            ISFILE = false;
        }
        in_x = Console.ReadLine();
        byte[] params_;
        if (ISFILE)
            params_ = File.ReadAllBytes(in_x);
        else
            params_ = UTF8Encoding.UTF8.GetBytes(in_x);

        {
            int i = 0;

            bool YBlocksCounter = false;
            bool ZBlocksCounter = true;
            bool XBlocksCounter = false;
            byte ZBlocksCounter_ = 0;
            byte YBlocksCounter_ = 0;
            byte XBlocksCounter_ = 0;
            int y = 0, z = 0;
            for (; i < params_.Length && i < 3072; i++)
            {
                if (ZBlocksCounter)
                    inputs_x[0, 0, ZBlocksCounter_] = params_[i];
                if (YBlocksCounter)
                    inputs_x[0, YBlocksCounter_, 0] = params_[i];
                if (XBlocksCounter)
                    inputs_x[XBlocksCounter_, 0, 0] = params_[i];

                SUM_X += params_[i];


                if (ZBlocksCounter_ < 1024 && ZBlocksCounter == true && YBlocksCounter == false && XBlocksCounter == false)
                    ZBlocksCounter_ += 1;
                else if (ZBlocksCounter_ <= 1024)
                {
                    ZBlocksCounter = false;
                    YBlocksCounter = true;
                    YBlocksCounter_ = 0;
                }
                else if (YBlocksCounter == true && YBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { YBlocksCounter_ += 1; }
                else if (YBlocksCounter_ <= 1024)
                {
                    XBlocksCounter = true;
                    ZBlocksCounter = false;
                    YBlocksCounter = false;
                }
                else if (XBlocksCounter == true && XBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { ZBlocksCounter_ += 1; }
            }
        }
        // ROUND ONE
        {
            Console.WriteLine("\n::Processing KEYS::\n");
            dynamic KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));

            System.Random rnd = new System.Random((int)KEY);
            // First Round XOR
            {
                int i = 0;

                bool YBlocksCounter = false;
                bool ZBlocksCounter = true;
                bool XBlocksCounter = false;
                byte ZBlocksCounter_ = 0;
                byte YBlocksCounter_ = 0;
                byte XBlocksCounter_ = 0;
                int y = 0, z = 0;
                for (; i < 3072; i++)
                {
                    if (ZBlocksCounter)
                        inputs_x[0, 0, ZBlocksCounter_] = inputs_x[0, 0, ZBlocksCounter_] ^ rnd.Next(1, 9999999);
                    if (YBlocksCounter)
                        inputs_x[0, YBlocksCounter_, 0] = inputs_x[0, YBlocksCounter_, 0] ^ rnd.Next(1, 9999999);
                    if (XBlocksCounter)
                        inputs_x[XBlocksCounter_, 0, 0] = inputs_x[XBlocksCounter_, 0, 0] ^ rnd.Next(1, 9999999);

                    if (ZBlocksCounter_ < 1024 && ZBlocksCounter == true && YBlocksCounter == false && XBlocksCounter == false)
                        ZBlocksCounter_ += 1;
                    else if (ZBlocksCounter_ <= 1024)
                    {
                        ZBlocksCounter = false;
                        YBlocksCounter = true;
                        YBlocksCounter_ = 0;
                    }
                    else if (YBlocksCounter == true && YBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { YBlocksCounter_ += 1; }
                    else if (YBlocksCounter_ <= 1024)
                    {
                        XBlocksCounter = true;
                        ZBlocksCounter = false;
                        YBlocksCounter = false;
                    }
                    else if (XBlocksCounter == true && XBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { ZBlocksCounter_ += 1; }
                }
            }
            // ROUND TWO - ~
            {
                for (int i2 = 0; i2 < 12; i2++)
                {


                    SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                    KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));

                    rnd = new System.Random((int)KEY);
                    // Round XOR - AND
                    {
                        int i = 0;

                        bool YBlocksCounter = false;
                        bool ZBlocksCounter = true;
                        bool XBlocksCounter = false;
                        byte ZBlocksCounter_ = 0;
                        byte YBlocksCounter_ = 0;
                        byte XBlocksCounter_ = 0;
                        int y = 0, z = 0;
                        for (; i < 3072; i++)
                        {
                            if (i % 2 == 0)
                            {
                                if (ZBlocksCounter)
                                    inputs_x[0, 0, ZBlocksCounter_] = inputs_x[0, 0, ZBlocksCounter_] ^ rnd.Next(1, 9999999);
                                if (YBlocksCounter)
                                    inputs_x[0, YBlocksCounter_, 0] = inputs_x[0, YBlocksCounter_, 0] ^ rnd.Next(1, 9999999);
                                if (XBlocksCounter)
                                    inputs_x[XBlocksCounter_, 0, 0] = inputs_x[XBlocksCounter_, 0, 0] ^ rnd.Next(1, 9999999);
                            }
                            else
                            {
                                if (ZBlocksCounter)
                                    inputs_x[0, 0, ZBlocksCounter_] = inputs_x[0, 0, ZBlocksCounter_] & rnd.Next(1, 9999999);
                                if (YBlocksCounter)
                                    inputs_x[0, YBlocksCounter_, 0] = inputs_x[0, YBlocksCounter_, 0] & rnd.Next(1, 9999999);
                                if (XBlocksCounter)
                                    inputs_x[XBlocksCounter_, 0, 0] = inputs_x[XBlocksCounter_, 0, 0] & rnd.Next(1, 9999999);
                            }
                            if (ZBlocksCounter_ < 1024 && ZBlocksCounter == true && YBlocksCounter == false && XBlocksCounter == false)
                                ZBlocksCounter_ += 1;
                            else if (ZBlocksCounter_ <= 1024)
                            {
                                ZBlocksCounter = false;
                                YBlocksCounter = true;
                                YBlocksCounter_ = 0;
                            }
                            else if (YBlocksCounter == true && YBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { YBlocksCounter_ += 1; }
                            else if (YBlocksCounter_ <= 1024)
                            {
                                XBlocksCounter = true;
                                ZBlocksCounter = false;
                                YBlocksCounter = false;
                            }
                            else if (XBlocksCounter == true && XBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { ZBlocksCounter_ += 1; }
                        }
                    }
                }
            }
            {
                for (int i2 = 0; i2 < 100; i2++)
                {


                    SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                    KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));

                    rnd = new System.Random((int)KEY);
                    // Round XOR - AND
                    {
                        int i = 0;

                        bool YBlocksCounter = false;
                        bool ZBlocksCounter = true;
                        bool XBlocksCounter = false;
                        byte ZBlocksCounter_ = 0;
                        byte YBlocksCounter_ = 0;
                        byte XBlocksCounter_ = 0;
                        int y = 0, z = 0;
                        for (; i < 3072; i++)
                        {
                            int source = rnd.Next(0, 1024);
                            int dest = rnd.Next(0, 1024);
                            byte Blocks_ = (byte)rnd.Next(1, 3);
                            if (i % 2 == 0)
                            {
                                if (true && Blocks_ == 1)
                                    inputs_x[0, 0, source] = inputs_x[0, 0, source] ^ inputs_x[0, 0, dest];
                                if (true && Blocks_ == 2)
                                    inputs_x[0, 0, source] = inputs_x[0, 0, source] ^ inputs_x[0, 0, dest];
                                if (true && Blocks_ == 3)
                                    inputs_x[0, 0, source] = inputs_x[0, 0, source] ^ inputs_x[0, 0, dest];
                            }
                            if (ZBlocksCounter_ < 1024 && ZBlocksCounter == true && YBlocksCounter == false && XBlocksCounter == false)
                                ZBlocksCounter_ += 1;
                            else if (ZBlocksCounter_ <= 1024)
                            {
                                ZBlocksCounter = false;
                                YBlocksCounter = true;
                                YBlocksCounter_ = 0;
                            }
                            else if (YBlocksCounter == true && YBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { YBlocksCounter_ += 1; }
                            else if (YBlocksCounter_ <= 1024)
                            {
                                XBlocksCounter = true;
                                ZBlocksCounter = false;
                                YBlocksCounter = false;
                            }
                            else if (XBlocksCounter == true && XBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { ZBlocksCounter_ += 1; }
                        }
                    }
                }
            }
        }






        // Print Output
        {
            int i = 0;

            bool YBlocksCounter = false;
            bool ZBlocksCounter = true;
            bool XBlocksCounter = false;
            byte ZBlocksCounter_ = 0;
            byte YBlocksCounter_ = 0;
            byte XBlocksCounter_ = 0;
            int y = 0, z = 0;
            for (; i < 3072; i++)
            {
                if (ZBlocksCounter)
                    Console.Write(inputs_x[0, 0, ZBlocksCounter_].ToString("X"));
                if (YBlocksCounter)
                    Console.Write(inputs_x[0, YBlocksCounter_, 0].ToString("X"));
                if (XBlocksCounter)
                    Console.Write(inputs_x[XBlocksCounter_, 0, 0].ToString("X"));

                if (ZBlocksCounter_ < 1024 && ZBlocksCounter == true && YBlocksCounter == false && XBlocksCounter == false)
                    ZBlocksCounter_ += 1;
                else if (ZBlocksCounter_ <= 1024)
                {
                    ZBlocksCounter = false;
                    YBlocksCounter = true;
                    YBlocksCounter_ = 0;
                }
                else if (YBlocksCounter == true && YBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { YBlocksCounter_ += 1; }
                else if (YBlocksCounter_ <= 1024)
                {
                    XBlocksCounter = true;
                    ZBlocksCounter = false;
                    YBlocksCounter = false;
                }
                else if (XBlocksCounter == true && XBlocksCounter_ < 1024 && YBlocksCounter == false && ZBlocksCounter == false) { ZBlocksCounter_ += 1; }
            }
        }



    }
}
